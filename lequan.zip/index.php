<?php
header("location: ''");
?>  