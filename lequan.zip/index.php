<?php

header("location: ''");
?>  