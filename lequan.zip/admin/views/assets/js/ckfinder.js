CKEDITOR.replace('editor1', {
    filebrowserBrowseUrl: '../lib/ckfinder/ckfinder.html',
    filebrowserUploadUrl: '../lib/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
    language: 'en'
});
CKEDITOR.replace('editor2', {
    filebrowserBrowseUrl: '../lib/ckfinder/ckfinder.html',
    filebrowserUploadUrl: '../lib/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Filn',
    language: 'en'

});
CKEDITOR.replace('editor3', {
    filebrowserBrowseUrl: '../lib/ckfinder/ckfinder.html',
    filebrowserUploadUrl: '../lib/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
    language: 'en'
});
CKEDITOR.replace('editor4', {
    filebrowserBrowseUrl: '../lib/ckfinder/ckfinder.html',
    filebrowserUploadUrl: '../lib/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
    language: 'en'
});