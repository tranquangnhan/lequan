
<div class="shipping-container">
    <div class="shipping-content">
        <div class="shipping-header">
            <div class="icon-wrapper">
                <img src="views/assets/img/vanchuyen.png" alt="Vận chuyển icon" class="shipping-icon">
            </div>
            <h1>CHÍNH SÁCH VẬN CHUYỂN</h1>
        </div>

        <div class="shipping-details">
            <div class="shipping-card">
                <div class="card-number">01</div>
                <div class="card-text">Hàng order từ 10-15 ngày trở lại, tính từ ngày nhà vận chuyển nhận được hàng từ nhà máy</div>
            </div>

            <div class="shipping-card">
                <div class="card-number">02</div>
                <div class="card-text">Hàng có sẵn FREESHIP nội thành TP.HCM</div>
            </div>

            <div class="shipping-card">
                <div class="card-number">03</div>
                <div class="card-text">Ship COD khác tỉnh 30.000 VNĐ</div>
            </div>
        </div>
    </div>
</div>