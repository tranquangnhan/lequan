<div class="warranty-container">
    <div class="warranty-content">
        <div class="warranty-header">
            <div class="icon-wrapper">
                <img src="views/assets/img/icon-bao-hanh.png" alt="Bảo hành icon" class="warranty-icon">
            </div>
            <h1>CHÍNH SÁCH BẢO HÀNH</h1>
        </div>

        <div class="warranty-details">
            <div class="warranty-card">
                <div class="card-number">01</div>
                <div class="card-text">Khách hàng mua sản phẩm đầu tiên bảo hành 6 tháng</div>
            </div>

            <div class="warranty-card">
                <div class="card-number">02</div>
                <div class="card-text">Khách hàng mua 2 đôi trở lên bảo hành vĩnh viễn</div>
            </div>

            <div class="warranty-card">
                <div class="card-number">03</div>
                <div class="card-text">Bảo hành các lỗi như sau: keo, còn những lỗi do sử dụng lâu về chất liệu, shop hỗ trợ 30% dành cho những khách hàng thân thiết</div>
            </div>
        </div>
    </div>
</div>