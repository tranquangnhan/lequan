<div class="container">
    <div class="row impressum">
        <div class="col-md-6">
        <h1 >Impressum</h1>
<p>Firma HangElla EG</p>
<p>Inhaberin Thu Hang Tran (Fachkosmetikerin)</p>
<p>Kontaktdaten:</p>
<p>Anschrift: <span>Steinbreite 17a 37603 Holzminden Niedersachen</span>  </p>
<p>Telefon: <span>+49 176 46778998</span> </p>
<p>E-Mail:  <span>hangella1506@gmail.com</span></p>
<p>Website: <span>http://hangella.de</span></p>
<p>USt-IdNr :<span> DE319825988</span></p>
<p>Zuständiger Aufsichtsbehörde: <span>Stadt Holzminden
Neue Str. 12
37603 Holzminden</span>
</p>
        </div>
    </div>
</div>