        <div class="main-content-wrapper" >
            <div class="page-content-inner pt--75 pb--80">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <p class="heading-color mb--30 text-center">Đổi mật khẩu.</p>
                            
                                <div class="form__group mb--30">
                                    <label for="order_id" class="form__label">Mật khẩu cũ</label>
                                    <input type="text" name="order_id" id="oldpass" class="form__input" placeholder="Nhập mật khẩu cũ.">
                                </div>
                                <div class="form__group mb--30">
                                    <label for="order_id" class="form__label">Mật khẩu mới </label>
                                    <input type="password" name="order_id" id="ResetPass" class="form__input" placeholder="Nhập mật khẩu mới.">
                                </div>
                                <div class="form__group mb--30">
                                    <label for="order_id" class="form__label">Nhập lại mật khẩu</label>
                                    <input type="password" name="order_id" id="ConfirmResetPass" class="form__input" placeholder="Nhập mật khẩu xác nhận.">
                                </div>
                                <div class="form__group text-center">
                                    <input type="submit" value="Xác Nhận" id="changpass" class="btn btn-size-sm">
                                </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Wrapper Start -->