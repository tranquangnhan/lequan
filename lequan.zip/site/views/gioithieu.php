<div class="containner">
    <div class="chinhsach">
        <div class="col-lg-5">
            <div class="row">
                
                <div class="col-lg-12 p-0 ">
                    <h1> GIỚI THIỆU</h1>
                </div>
            </div>
            <div class="text">
            - HÀNG ĐƯỢC NHẬP TỪ CÁC NHÀ MÁY CHINA . </div>
             <div class="text">
             - NHẬP TRỰC TIẾP KHÔNG QUA TRUNG GIAN.</div>
             <div class="text">
             - CHẤT LƯỢNG COPY ĐẠT 95% - 97% !
             </div>
             <div class="text">
             - SHOP LUÔN LUÔN CHỌN PHIÊN BẢN CAO CẤP TỪ CÁC NHÀ MÁY OG,G5,H12,S2,DONGGUAN,GOD,X,BC,PK,LJR,GT,ST...
             </div>
        </div>
    </div>  
   
</div>